// Valeurs publiques uniquement : jamais de clé secret ou service_role.
window.INFOCLASS_CONFIG = { supabaseUrl: "", supabaseKey: "" };
